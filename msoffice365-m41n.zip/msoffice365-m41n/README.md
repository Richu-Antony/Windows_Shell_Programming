# Microsoft Office 365 | Free Lifetime Activation
> To remove this repo please create an issue with valid reason

<img src='/img/microsoft365.jpg' width='700' height='360'>

<br>

## Activation Steps 🪛
> [PROTIP] Download all resources at once ([_Click here_](https://github.com/Divinemonk/msoffice365/archive/refs/tags/downloads.zip) to start downloading all (3) files as zip)

- Download ⬇️ `Office Setup` Executable ([__Click here__](https://github.com/Divinemonk/msoffice365/releases/download/downloads/OfficeSetup.exe) to start downloading)
    - Download size : `7 MB`

<br>

- Run the downloaded `OfficeSetup.exe` and install `microsoft office  365`
   - Take note that you need `active internet connection` to download and install all `Office Application`
   - Internet data needed about `2 GB`
   - Internal storage needed about `3 GB`

<br>

- Download ⬇️ activator script 
    - Microsoft Office `2016 License` Activation Script | &nbsp; ([__Click here__](https://github.com/Divinemonk/msoffice365/releases/download/downloads/office_2016.cmd) to start downloading)
    - Microsoft Office `2019 License` Activation Script | &nbsp; ([__Click here__](https://github.com/Divinemonk/msoffice365/releases/download/downloads/office_2019.cmd) to start downloading)

<br>

- Close all office apps (if opened any) 
- RUN the script as `Administrator` ([right click on script > run as administrator](https://www.google.com/search?q=run+as+administrator))

<br>

## `Microsoft Office 365` activated for lifetime ❗❗

<img src='/img/msoffice-banner.jpg' width='700' height='360'>

<br>
<br>

## ⚠️ Disclaimers ⚠️

- Check the sha1sum/md5sum of the files [__here__](sums.md)

<br>

- Activation script for `Office 2016` works fine, but sometimes for `Office 2019` Windows Defender deletes the file ([check this article](https://www.quora.com/I-faced-this-thread-HackTool-Win32-AutoKMS-in-windows-defender-win-10-pro-What-should-I-do)). The `HackTool: Win32/AutoKMS` is not virus ([Google search results](https://www.google.com/search?q=is+HackTool%3A+Win32%2FAutoKMS+virus)) , so don't worry - turn off windows defender OR (recommended) select `allow threats on device` option ([How to allow threat in windows?](https://www.google.com/search?q=allow+threats+in+windows)) to use 'office_2019.cmd' to activate Office 2019 License.

<br>

> NOTE | [Developer](https://github.com/Divinemonk) is not responsible for any datalose or crashes. It's end users responsiblity & use at your own risk. Its `99 %` safe but sometimes `1 %` sucks !
