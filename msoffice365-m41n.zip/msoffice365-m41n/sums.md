# Sha1sum / Md5sum  of files
> Why to sha1sum is given ? - [ANS](https://www.google.com/search?q=Why+to+sha1sum+is+given)

<br>
<br>

## Sha1sums

- `OfficeSetup.exe` : 
- `office_2016.bat` :
- `office_2019.bat` :

<br>
<br>

## Md5sums

- `OfficeSetup.exe` : 
- `office_2016.bat` :
- `office_2019.bat` :
